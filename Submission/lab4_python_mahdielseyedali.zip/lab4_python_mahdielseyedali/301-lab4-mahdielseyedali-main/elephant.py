def getUserChoice():
    print('What do you want to display? ')
    print('1. Logo')
    print('2. Plus sign')
    print('3. Equals sign')
    print('4. Raspberry')
    print('5. Heart')
    print('6. Elephant')
    print('0. Exit')
    choice = int(input("Enter a number"))
    while choice > 0 and choice < 7:

        try:
            choice_type = type(choice)
            if choice_type == str:
                print("input is a string not a number")

        except ValueError:
            print("Invalid Input, please enter a number from the menu")

    return choice
